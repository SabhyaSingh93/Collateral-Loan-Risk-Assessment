package com.cts.clra.entity;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
/**
 * 
 * Pojo class for Loan
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Loan {

	private int loanProductId;

	private String loanProductName;

	private int maxLoanEligible;

	private double interest;

	private int tenureYear;

	private String collateralType;

	private List<CustomerLoan> customerLoanList = new ArrayList<CustomerLoan>();

}