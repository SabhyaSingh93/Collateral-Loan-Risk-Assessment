package com.cts.clra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;
/**
 * 
 * this is the main class
 * @EnableFeignClients to enable component scanning of the interfaces which are feign clients
 *
 */

@EnableAutoConfiguration
@Configuration
@EnableFeignClients
@SpringBootApplication
public class LoanWebPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanWebPortalApplication.class, args);
	}

}