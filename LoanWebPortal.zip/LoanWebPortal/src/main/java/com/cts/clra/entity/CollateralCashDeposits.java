package com.cts.clra.entity;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
/**
 * 
 * Pojo class for Cash deposit Collateral
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CollateralCashDeposits {

	private int loanId;
	@NotBlank
	private String ownerName;
	@NotNull
	private String bankName;
	@NotNull(message = "loan product required")
	private long accountNumber;
	@NotNull(message = "loan product required")
	private double depositAmount;
	@NotNull(message = "loan product required")
	private double lockPeriod;
	private int collateralId;

}