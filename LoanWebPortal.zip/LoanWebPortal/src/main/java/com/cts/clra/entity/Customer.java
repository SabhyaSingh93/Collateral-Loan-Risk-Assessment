package com.cts.clra.entity;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
/**
 * 
 * pojo class for Cutomer
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Customer {

	private int customerId;

	private String customerName;

	private List<CustomerLoan> customerLoanList = new ArrayList<CustomerLoan>();

}