package com.cts.clra.feignproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.clra.entity.CollateralRisk;
/**
 * 
 * Feign Client for Risk service
 *
 */
@FeignClient(name = "risk-service", url = "${risk.path}")
public interface RiskFeignClient {

	/**
	 * 
	 * @param token
	 * @param loanId
	 * Gets risk for real estate
	 */
	@GetMapping(path = "/getCollateralRisk/realEstate/{loanId}")
	public ResponseEntity<CollateralRisk> getcollatrolrisk(@RequestHeader(name = "Authorization") String token,
			@PathVariable("loanId") int loanId);

	/**
	 * 
	 * @param token
	 * @param loanId
	 * Gets risk for Cash Deposits
	 */
	@GetMapping(path = "/getCollateralRisk/cashDeposits/{loanId}")
	public ResponseEntity<CollateralRisk> getcollatrolriskForCashDeposits(
			@RequestHeader(name = "Authorization") String token, @PathVariable("loanId") int loanId);
}