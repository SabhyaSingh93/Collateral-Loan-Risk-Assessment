package com.cts.clra.entity;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * 
 * Pojo class for customer loan data
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerLoanData {

	private int loanId;
	@NotNull(message = "loan product required")
	private int loanProductId;
	@NotNull(message = "customerIdrequired")
	private int customerId;
	private double loanPrincipal;
	@NotNull(message = "tenureYear required")
	private int tenureYear;
	private double interest;
	@NotNull(message = "emi required")
	//private int emi;
	private int collateralId;
	private String productName;
}